Install node modules using "npm install"
To run the application "npm start"